// Copyright header

#include "form.h"

Form::Form(QWidget *parent) :
    QWidget(parent)
{
    ui.setupUi(this);
}
