class AnyClass
{
public:
    AnyClass() {}
};

#define SOME_MACRO_NAME( X )\
{\
  (X) = 1;\
}\

