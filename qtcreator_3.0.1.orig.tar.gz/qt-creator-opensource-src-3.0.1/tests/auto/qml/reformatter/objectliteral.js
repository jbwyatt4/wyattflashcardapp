var x = {
    x: 12,
    y: {
        x: 12,
        y: "abc",
        z: function (x) {
            return a
        },
        abc: 15
    },
    z: 12
}
