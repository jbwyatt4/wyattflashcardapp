# 1 "data/empty-macro.cpp"


class             Foo {
};

class                Foo2 {
};

class                   Foo3 {
};

class                      Foo3 {
};
