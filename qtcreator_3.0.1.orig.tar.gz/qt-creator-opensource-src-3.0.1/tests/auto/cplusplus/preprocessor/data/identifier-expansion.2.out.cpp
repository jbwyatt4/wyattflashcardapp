# 1 "data/identifier-expansion.2.cpp"



# expansion begin 45,12 ~1
test
# expansion end
# expansion begin 58,4 ~1
test
# expansion end
# 4 "data/identifier-expansion.2.cpp"
                 ;

void
# expansion begin 70,12 ~1
test
# expansion end
# 6 "data/identifier-expansion.2.cpp"
                 ();
