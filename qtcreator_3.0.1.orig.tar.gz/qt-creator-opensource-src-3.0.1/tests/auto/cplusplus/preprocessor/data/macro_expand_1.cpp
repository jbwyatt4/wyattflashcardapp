#define DECLARE_CLASS(s) class s
DECLARE_CLASS(QString);
