#define EMPTY_MACRO

class EMPTY_MACRO Foo {
};

class EMPTY_MACRO    Foo2 {
};

class       EMPTY_MACRO Foo3 {
};

class       EMPTY_MACRO    Foo3 {
};
