#define foobar(a)       a
#define food            foobar

void baz()
{
    int aaa;
    food(aaa);
}
