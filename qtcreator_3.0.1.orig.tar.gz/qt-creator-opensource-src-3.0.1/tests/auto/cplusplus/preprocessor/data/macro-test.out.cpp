# 1 "data/macro-test.cpp"






void thisFunctionIsEnabled();
# 21 "data/macro-test.cpp"
void thisFunctionIsEnabled2();
# 31 "data/macro-test.cpp"
void thisFunctionIsEnabled3();





