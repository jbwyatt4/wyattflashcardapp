# 1 "data/poundpound.1.cpp"
struct QQ {};



# expansion begin 50,2 ~4
typedef QQ PPCC;
# expansion end
# 7 "data/poundpound.1.cpp"
typedef PPCC RR;
