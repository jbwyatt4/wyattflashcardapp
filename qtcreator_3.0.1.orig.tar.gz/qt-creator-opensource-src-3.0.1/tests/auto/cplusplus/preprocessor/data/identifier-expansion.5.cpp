#define FOOBAR

#ifdef FOO

class FOOBAR Zoo {
};

#endif
