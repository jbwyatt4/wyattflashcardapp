# 1 "data/identifier-expansion.4.cpp"



void baz()
{
    int aaa;
# expansion begin 88,4 7:9
aaa
# expansion end
# 7 "data/identifier-expansion.4.cpp"
             ;
}
