# 1 "data/identifier-expansion.1.cpp"


# expansion begin 19,4 ~1
test
# expansion end
# expansion begin 24,4 ~1
test
# expansion end
# 3 "data/identifier-expansion.1.cpp"
         ;

void
# expansion begin 36,4 ~1
test
# expansion end
# 5 "data/identifier-expansion.1.cpp"
         ();
