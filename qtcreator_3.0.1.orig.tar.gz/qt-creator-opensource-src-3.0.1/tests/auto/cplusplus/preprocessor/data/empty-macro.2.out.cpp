# 1 "data/empty-macro.2.cpp"





class Test {
private:
# expansion begin 182,14 8:19 ~2 8:19 ~3 8:19 ~5 8:19 ~3
Test(const Test &); Test &operator=(const Test &);
# expansion end
# 10 "data/empty-macro.2.cpp"
public:
    Test();
};
