#define TEST test

TEST TEST;

void TEST();
