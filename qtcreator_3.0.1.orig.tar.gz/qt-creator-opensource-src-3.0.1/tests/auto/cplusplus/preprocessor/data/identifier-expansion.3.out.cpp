# 1 "data/identifier-expansion.3.cpp"
# 12 "data/identifier-expansion.3.cpp"
enum op_code {
# expansion begin 195,14 ~4
op_ADD, op_SUB,
# expansion end
# expansion begin 232,14 ~4
op_DIV, op_MUL,
# expansion end
# 15 "data/identifier-expansion.3.cpp"
};


static const char *names[] = {
# expansion begin 301,14 ~4
"ADD", "SUB",
# expansion end
# expansion begin 331,14 ~4
"DIV", "MUL",
# expansion end
# 21 "data/identifier-expansion.3.cpp"
};
