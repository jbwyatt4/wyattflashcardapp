#define a b
#define b a

b
a
