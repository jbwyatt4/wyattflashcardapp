
void hey(int a) {
    int b = a + 10;
    b;
}

class hello
{
public:
    bool doit() { return true; }
    bool dothat();
    void run();
};

bool hello::dothat()
{
    bool should = true;
    if (should) {
        int i = 10;
        while (i > 0) {
            run();
            --i;
        }
    }
    return false;
}
