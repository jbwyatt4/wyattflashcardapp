# 1 "data/macro_expand_1.cpp"

# expansion begin 33,13 ~1 2:14
class QString
# expansion end
# 2 "data/macro_expand_1.cpp"
                      ;
