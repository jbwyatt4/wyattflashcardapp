# 1 "data/recursive.1.cpp"



# expansion begin 25,1 ~1
b
# expansion end
# expansion begin 27,1 ~1
a
# expansion end
# 6 "data/recursive.1.cpp"
