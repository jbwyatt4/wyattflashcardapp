WRITE IN C  (sung to The Beatles "Let it Be")

When I find my code in tons of trouble,
Friends and colleagues come to me,
Speaking words of wisdom:
"Write in C."

As the deadline fast approaches,
And bugs are all that I can see,
Somewhere, someone whispers"
"Write in C."

Write in C, write in C,
Write in C, write in C.
LISP is dead and buried,
Write in C.

I used to write a lot of FORTRAN,
for science it worked flawlessly.
Try using it for graphics!
Write in C.

If you've just spent nearly 30 hours
Debugging some assembly,
Soon you will be glad to
Write in C.

Write in C, write in C,
Write In C, yeah, write in C.
Only wimps use BASIC.
Write in C.

Write in C, write in C,
Write in C, oh, write in C.
Pascal won't quite cut it.
Write in C.

{
  Guitar Solo
}

Write in C, write in C,
Write in C, yeah, write in C.
Don't even mention COBOL.
Write in C.

And when the screen is fuzzy,
And the edior is bugging me.
I'm sick of ones and zeroes.
Write in C.

A thousand people people swear that T.P.
Seven is the one for me.
I hate the word PROCEDURE,
Write in C.

Write in C, write in C,
Write in C, yeah, write in C.
PL1 is 80's,
Write in C.

Write in C, write in C,
Write in C, yeah, write in C.
The government loves ADA,
Write in C.
