# 1 "data/macro_expand.c"



A:
# expansion begin 32,1 ~1
Y
# expansion end
# 5 "data/macro_expand.c"
