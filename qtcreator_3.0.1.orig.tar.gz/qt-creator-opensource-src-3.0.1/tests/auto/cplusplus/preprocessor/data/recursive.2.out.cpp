# 1 "data/recursive.2.cpp"




# expansion begin 70,1 ~2 5:2 ~3 5:2 ~3 5:2 ~3 5:2 ~3 5:2 ~3 5:2 ~1
b(1) c(1) b(1) b(1) a(1) b(1)
# expansion end
# expansion begin 75,1 ~2 6:2 ~3 6:2 ~3 6:2 ~3 6:2 ~3 6:2 ~3 6:2 ~1
a(1) b(1) a(1) a(1) c(1) a(1)
# expansion end
# 7 "data/recursive.2.cpp"
