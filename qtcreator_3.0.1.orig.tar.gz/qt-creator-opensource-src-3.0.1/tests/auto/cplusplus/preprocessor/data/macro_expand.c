#define X() Y
#define Y() X

A: X()()()
