thread_local int i;
