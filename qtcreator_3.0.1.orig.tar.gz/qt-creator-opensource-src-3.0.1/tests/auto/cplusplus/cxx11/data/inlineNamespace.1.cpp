
inline namespace zoo {
    void foo();
}

