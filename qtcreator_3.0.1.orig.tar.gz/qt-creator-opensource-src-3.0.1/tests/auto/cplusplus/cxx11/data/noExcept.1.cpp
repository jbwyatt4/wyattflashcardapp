void f() noexcept {
}

void g() noexcept(1) {
}
