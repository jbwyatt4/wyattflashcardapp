auto x = int{};
auto y = Foo{};
auto z = typename Foo<T>{};

auto d = new C(1, abc...);
auto e = new C{1, 2, 3};
