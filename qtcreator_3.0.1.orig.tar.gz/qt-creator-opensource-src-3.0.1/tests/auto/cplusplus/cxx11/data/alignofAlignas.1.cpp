int i = alignof(int);
int t = alignof(C::foo) * 7 + alignof(Foo *);
