#include "header.h"

#ifdef BUS_ONE
int one;
#endif

#ifdef BUS_TWO
int two;
#endif
