#ifdef SUB1
#  define BUS_ONE
#endif

#ifdef SUB2
#  define BUS_TWO
#endif
