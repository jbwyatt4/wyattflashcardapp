int someGlobal;
