// Copyright header

#include "foo.h"

Foo::Foo()
{
}
