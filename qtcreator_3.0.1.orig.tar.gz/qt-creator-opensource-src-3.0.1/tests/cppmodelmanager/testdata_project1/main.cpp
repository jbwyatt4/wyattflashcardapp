// Copyright header

#include "foo.h"

int main()
{
    Foo foo;
    return 1;
}
