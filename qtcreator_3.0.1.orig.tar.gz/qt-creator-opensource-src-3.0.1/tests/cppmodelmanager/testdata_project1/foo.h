// Copyright header

#ifndef FOO_H
#define FOO_H

class Foo
{
public:
    Foo();
};

#endif // FOO_H
