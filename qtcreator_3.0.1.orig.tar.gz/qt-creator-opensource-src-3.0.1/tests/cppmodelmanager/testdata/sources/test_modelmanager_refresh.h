#ifndef test_modelmanager_refresh_h
#define test_modelmanager_refresh_h

#ifdef TEST_DEFINE
#define TEST_DEFINE_DEFINED 1
#endif

#endif // test_modelmanager_refresh_h
