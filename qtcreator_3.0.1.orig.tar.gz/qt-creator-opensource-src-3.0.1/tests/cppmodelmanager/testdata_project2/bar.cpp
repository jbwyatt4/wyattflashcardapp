// Copyright header

#include "bar.h"

Bar::Bar()
{
}
