// Copyright header

#include "bar.h"

int main()
{
    Bar bar;
    return 1;
}
