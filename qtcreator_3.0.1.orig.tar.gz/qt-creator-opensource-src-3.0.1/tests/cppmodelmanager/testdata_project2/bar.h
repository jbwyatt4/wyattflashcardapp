// Copyright header

#ifndef BAR_H
#define BAR_H

class Bar
{
public:
    Bar();
};

#endif // BAR_H
